#ifndef _KERN_TRAP_TSYSCALLARG_H_
#define _KERN_TRAP_TSYSCALLARG_H_

#ifdef _KERN_

unsigned int get_curid(void);

#endif  /* _KERN_ */

#endif  /* !_KERN_TRAP_TSYSCALLARG_H_ */
