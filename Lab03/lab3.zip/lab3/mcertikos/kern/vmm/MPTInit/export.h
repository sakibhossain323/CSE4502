#ifndef _KERN_VMM_MPTINIT_H_
#define _KERN_VMM_MPTINIT_H_

#ifdef _KERN_

void paging_init(unsigned int mbi_addr);

#endif  /* _KERN_ */

#endif  /* !_KERN_VMM_MPTINIT_H_ */
