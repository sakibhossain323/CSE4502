#ifndef _KERN_THREAD_H_
#define _KERN_THREAD_H_

typedef enum {
    TSTATE_READY = 0,
    TSTATE_RUN,
    TSTATE_SLEEP,
    TSTATE_DEAD
} t_state;

#endif  /* !_KERN_THREAD_H_ */
